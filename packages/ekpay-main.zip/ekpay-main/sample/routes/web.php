<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/success', function () {
    return 'Success Page';
});

Route::get('/fail', function () {
    return 'Fail Page';
});

Route::get('/cancel', function () {
    return 'Cancel Page';
});

Route::get('/ekpay', [\App\Http\Controllers\EkpayController::class, 'index']);
Route::post('/ekpay', [\App\Http\Controllers\EkpayController::class, 'store']);
Route::get('/transact', [\App\Http\Controllers\EkpayController::class, 'transact']);
