<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Streamstech\Ekpay\Customer;
use Streamstech\Ekpay\EkpayService;
use Streamstech\Ekpay\EkpayIpnService;
use Streamstech\Ekpay\Transaction;

class EkpayController extends Controller
{
    public function index()
    {
        return view('ekpay.index');
    }

    public function ipn(EkpayIpnService $service)
    {
        return $service->response();
    }

    public function transact(EkpayService $service): string
    {
        $customer = new Customer(
            'C001',
            'Mahabubul Hasan',
            '01717508422',
            'mahabubul.hasan@streamstech.com',
            'Dhaka 1216'
        );

        $transaction = new Transaction(
            'T0' . rand(1, 9999),
            '99',
            'OD001',
            'Just Testing the order'
        );

        $service->send($customer, $transaction);
        return true;
    }

    public function store(Request $request, EkpayService $service)
    {
        $customer = new Customer($request->cust_name, $request->cust_mobo_no);

        $transaction = new Transaction(
            'T0' . rand(1, 9999),
            $request->get('trnx_amt'),
        );

        $service->send($customer, $transaction);
    }
}
