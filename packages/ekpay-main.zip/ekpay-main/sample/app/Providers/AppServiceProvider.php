<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Streamstech\Ekpay\Config\Config;
use Streamstech\Ekpay\Config\ConfigKey;
use Streamstech\Ekpay\EkpayService;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(EkpayService::class, function ($app) {
            $config = new Config();
            $config
                ->set(ConfigKey::SUCCESS_URL, 'http://127.0.0.1:8000/success')
                ->set(ConfigKey::CANCEL_URL, 'http://127.0.0.1:8000/cancel')
                ->set(ConfigKey::FAIL_URL, 'http://127.0.0.1:8000/fail')
                ->set(ConfigKey::MERCHANT_REG_ID, 'kcc_test')
                ->set(ConfigKey::MERCHANT_PAS_KEY, 'KhulNaciTy@tsT29')
                ->set(ConfigKey::IPN_CHANNEL, '2') // 0=None, 1=Both, 2=Email, 3=API
                ->set(ConfigKey::IPN_URI, 'https://tserm.com/imis/ipn.php')
                ->set(ConfigKey::IPN_EMAIL, 'codehasan@gmail.com')
                ->set(ConfigKey::MAC, '1.1.1.1');

            return new EkpayService($config);
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
