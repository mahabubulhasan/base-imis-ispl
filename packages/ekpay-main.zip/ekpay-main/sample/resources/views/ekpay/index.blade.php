<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
      crossorigin="anonymous">


<div class="container" style="margin-top: 10px;">
    <div class="col-md-7">
        <form action="/ekpay" method="post">
            {{ csrf_field() }}
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 col-form-label">Customer Name</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="cust_name" id="inputEmail3">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 col-form-label">Customer Email</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="cust_email" id="inputEmail3">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Customer ID</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="cust_id" id="inputPassword3">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Customer Address</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="cust_mail_addr" id="inputPassword3">
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 col-form-label">Customer Mobile Number</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="cust_mobo_no" id="inputPassword3">
                </div>
            </div>

            <hr/>
            <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 col-form-label">trnx Amt</label>
                <div class="col-sm-8">
                    <input type="number" step="0.01" class="form-control" name="trnx_amt" id="inputEmail3">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-sm-4"></div>
                <div class="col-sm-8">
                    <button type="submit" class="btn btn-primary">Payment</button>
                </div>
            </div>
        </form>
    </div>
</div>
