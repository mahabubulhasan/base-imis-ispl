## EkPay
[EkPay](https://ekpay.gov.bd/) Payment gateway library for Laravel framework.
## EkPay Sequence Diagram
<p align="center">
  <img src="assets/img/ekpay_sequence_diagram.png" height="450px" /><br/>
    <b> EkPay Sequence Diagram </b>
</p>

## Installation
The package can be installed through Composer:

```
composer require streamstech/ekpay
```

## Configuration
In your laravel `app/Providors/AppServiceProvider.php` add/edit your register method like that code given below
```php
<?php
namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use Streamstech\Ekpay\Config\Config;
use Streamstech\Ekpay\Config\ConfigKey;
use Streamstech\Ekpay\EkpayService;

class AppServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(EkpayService::class, function ($app) {
            $config = new Config();
            $config
                ->set(ConfigKey::SUCCESS_URL, 'http://localhost:8080/success')
                ->set(ConfigKey::CANCEL_URL, 'http://localhost:8080/cancel')
                ->set(ConfigKey::FAIL_URL, 'http://localhost:8080/fail')
                ->set(ConfigKey::MERCHANT_REG_ID, '-')
                ->set(ConfigKey::MERCHANT_PAS_KEY, '-')
                ->set(ConfigKey::IPN_CHANNEL, '2') // 0=None, 1=Both, 2=Email, 3=API
                ->set(ConfigKey::IPN_URI, '')
                ->set(ConfigKey::IPN_EMAIL, 'ipnmail@gmail.com')
                ->set(ConfigKey::MAC, '1.1.1.1');

            return new EkpayService($config);
        });
    }
}

```
## Usage
```php
<?php
namespace App\Http\Controllers;

use Streamstech\Ekpay\Customer;
use Streamstech\Ekpay\EkpayService;
use Streamstech\Ekpay\Transaction;

class EkpayController extends Controller
{
    public function transact(EkpayService $service): string
    {
        $customer = new Customer(
            'Customer Id',
            'Customer Name',
            'Customer Mobile',
            'Customer Email',
            'Customer Address'
        );
        $transaction = new Transaction(
            'Transaction Id', //Must be unique
            'ammount', //Must be greater then 0
            'Order Id',
            'Order Details'
        );

        $service->send($customer, $transaction);
        return true;
    }

    public function statusCheck(EkpayService $service)
    {
        $json_response = $service->status('tx0001', '2026-07-22');
    }
}
```
## Fields
In your laravel `app/Providors/AppServiceProvider.php` ConfigKey fields
| Actual Name   | Parameter Description | M/O  |
| ------------- | ------------- | ------------- |
| SUCCESS_URL  | success Url, PO will redirect on this url after a successful transaction took place.  | M |
| FAIL_URL  | Failure URL, PO will redirect on this urlafter a successful transaction took place. With parameter of payment status failed and reason  | M |
| CANCEL_URL  | Cancel Url, PO will redirect on this urlafter a successful transaction took place.With parameter of payment status canceled and reason.  | M |
| MERCHANT_REG_ID  | Merchant register ID with ekpay.   | M |
| MERCHANT_PAS_KEY  | Merchant register ID with ekpay.   | M |
| IPN_CHANNEL  | Merchant choice, How merchantwant to receive IPN. 0-None,1-Both,2-Only through Email, 3- Through API  | M |
| IPN_URI  | Api exposed by merchant for IPN Communication   | M/O |
| IPN_EMAIL  | Email Address of merchant, In where PG will send instant payment notification.  | M/O |
| MAC  | For mobile APPS. For test use 1.1.1.1 in this field   | M/O |

In your laravel `Streamstech\Ekpay\Customer` Parameter fields
| Parameter No   | Parameter Description | M/O  |
| ------------- | ------------- | ------------- |
| cust_id   | Customer Id  | M/O |
| cust_name  | Customer Name  | M/O |
| cust_mobo_no  | Customer Mobile  | M/O |
| cust_email  | Customer Email  | M/O |
| cust_mail_addr  | Customer Address  | M/O |

In your laravel `Streamstech\Ekpay\Transaction` Parameter fields
| Parameter No   | Parameter Description | M/O  |
| ------------- | ------------- | ------------- |
| trnx_id   | Transaction ID of Merchant (Must be unique)  | M |
| trnx_amt  | Ammount. (Must be greater then 0)  | M |
| ord_id  | Order Id  | M/O |
| ord_det  | Order Details  | M/O |
| currency  | Amount currency (BDT/USD…etc]) (Default BDT)  | M |

## How Use EkPay Redirect Payment Page

1. IPN API should be implemented at merchant side. The Transaction status posted through IPN API will be counted as final.

2. For dummy PG,  Go to mobile banking tab and select SITPG (only this gateway will perform as test) as payment service provider. It will redirect you to a dummy payment gateway page. You can select the operation on that page(success, fail, cancel). use pin 3124. After submission it will redirect you to your provided url(s_uri, f_uri, c_uri) based on selected action.

3. Length of Transaction ID should be within 36.

4. Use your whitelisted IP as "mac_address" parameter while initializing transaction. for test use 1.1.1.1 in this field. for live you have to use your whitelisted IP here.

## Example Status Response
```json
{
    "secure_token": "eyJhbGciOiJIUzUxM9.eyJzdWIiOiJsYWtzaG1pcHVyX3BvdXJvX2ltaXMiJhdXRoIjoiUk9MRV9NRVJDSEFOVCIsInJlZl9pZCI6IllkSjEiLCJleHAiOjE3ODQ2OTkyMzR9.o99Bt6dNIVC_zalFdMzamsYFFCjUXw5cipBtQ-6n5wiVVKHwa45ectartvjT6bxU-S6m0vDzLkmBLpbnCaGg",
    "msg_code": "1020",
    "msg_det": "Transaction completed successfully",
    "req_timestamp": "2026-07-22 11:17:13 GMT+06:00",
    "basic_Info": {
        "mer_reg_id": "merchant_id",
        "ipn_info": "ipn_chanel=3;ipn_uri=https://example.com/payment/ipn",
        "redirect_to": "https://examples.com/payment/success",
        "dgtl_sign": "WEB",
        "ord_desc": "",
        "remarks": "Actual selected card type : NOTHING PROVIDED"
    },
    "cust_info": {
        "cust_id": "CUST-9d01b2",
        "cust_name": "Mahabubul Hasan",
        "cust_mobo_no": "+880170000022",
        "cust_email": "",
        "cust_mail_addr": ""
    },
    "scroll_no": null,
    "trnx_info": {
        "trnx_amt": "1500.00",
        "trnx_id": "2607221117141f583",
        "mer_trnx_id": "TX-000000000A",
        "curr": "BDT",
        "pi_trnx_id": "9916467893",
        "pi_charge": "22.5",
        "ekpay_charge": "0.0",
        "pi_discount": "0.0",
        "discount": "0.0",
        "promo_discount": "0.0",
        "total_ser_chrg": "22.5",
        "total_pabl_amt": "1522.50"
    },
    "pi_det_info": {
        "pay_timestamp": "22-07-2026 11:17:25 AM",
        "pi_name": "SIT-PG",
        "pi_type": "sitpg",
        "pi_number": "NOTHING PROVIDED",
        "pi_gateway": "SIT-PG",
        "card_holder_name": null
    }
}
```
