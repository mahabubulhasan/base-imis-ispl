<?php

namespace Tests;

use Tests\TestCase;


class EkPayTest extends TestCase
{
    /** @test */
    public function test_ekpay()
    {
        $this->assertTrue(true);
    }
}