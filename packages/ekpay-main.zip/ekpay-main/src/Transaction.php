<?php

namespace Streamstech\Ekpay;

class Transaction implements Arrayable
{
    private string $transaction_id;
    private string $amount;
    private string $order_id;
    private string $order_details;
    private string $currency;

    public function __construct(
        string $transaction_id,
        string $amount,
        string $currency = "BDT",
        string $order_details = null,
        string $order_id = null)
    {
        $this->transaction_id = $transaction_id;
        $this->amount = $amount;
        $this->order_id = $order_id ? $order_id : "";
        $this->order_details = $order_details ? $order_details : "";
        $this->currency = $currency;
    }

    public function getTransactionId(){
        return $this->transaction_id;
    }

    public function asArray(): array
    {
        return [
            'trnx_id' => $this->transaction_id,
            'trnx_amt' => $this->amount,
            'trnx_currency' => $this->currency,
            'ord_id' => $this->order_id,
            'ord_det' => $this->order_details,
        ];
    }
}