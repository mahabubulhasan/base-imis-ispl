<?php

namespace Streamstech\Ekpay;

class Customer implements Arrayable
{
    private string $customer_id;
    private string $name;
    private string $mobile_no;
    private string $email;
    private string $address;

    public function __construct(
        string $name,
        string $mobile_no,
        string $customer_id = null,
        ?string $email = null,
        ?string $address = null
    ) {
        $this->customer_id = $customer_id ? $customer_id : "";
        $this->name = $name;
        $this->mobile_no = $mobile_no;
        $this->email = $email ? $email : "";
        $this->address = $address ? $address : "";
    }

    public function asArray(): array
    {
        return [
            'cust_id' => $this->customer_id,
            'cust_name' => $this->name,
            'cust_mobo_no' => $this->mobile_no,
            'cust_email' => $this->email,
            'cust_mail_addr' => $this->address
        ];
    }
}