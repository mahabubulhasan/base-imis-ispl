<?php

namespace Streamstech\Ekpay;

use GuzzleHttp\Client;
use Psr\Http\Message\ResponseInterface;
use Streamstech\Ekpay\Config\Config;
use Streamstech\Ekpay\Config\EkpayRequest;
use Streamstech\Ekpay\Arrayable;
use Streamstech\Ekpay\Config\SearchRequest;

class EkpayService
{
    private Config $config;

    public function __construct(?Config $config = null)
    {
        if ($config != null) {
            $this->setConfig($config);
        }
    }

    public function setConfig(Config $config)
    {
        $this->config = $config;
    }

    public function send(Customer $customer, Transaction $transaction)
    {
        $response = $this->post(
            $this->config->getEkpayTokenUrl(),
            new EkpayRequest($customer, $transaction, $this->config)
        );

        if ($response->getStatusCode() == 200) {
            $content = json_decode($response->getBody()->getContents());
            if (!$content->secure_token) {
                return false;
            }

            $url = $this->config->getEkpayRedirectUrl() . '?' . http_build_query([
                    'sToken' => $content->secure_token,
                    'trnsID' => $transaction->getTransactionId()
                ]);

            header('Location: ' . $url);
            exit;
        }

        return false;
    }

    public function status(string $transactionId, string $transaction_date): ResponseInterface
    {
        $response = $this->post(
            $this->config->getEkpaySearchTransactionUrl(),
            new SearchRequest($transactionId, $transaction_date, $this->config)
        );

        if ($response->getStatusCode() == 200) {
            return $response;
        }

        return $response;
    }

    /**
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function post(string $url, Arrayable $ekpay): ResponseInterface
    {
        $client = new Client();
        return $client->request('POST', $url, ['json' => $ekpay->asArray()]);
    }
}