<?php

namespace Streamstech\Ekpay;

class EkpayIpnService
{
    public function response($response = [])
    {
        $date = new \DateTime('now', new \DateTimeZone('Asia/Dhaka'));
        
        return array_merge([
            "ack_code" => "ack001",
            "ack_msg" => "Acknowledge Successfully.",
            "ack_timestamp" => $date->format('Y-m-d H:i:s') . ' GMT+6'
        ], $response);
    }
}
