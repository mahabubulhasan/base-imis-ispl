<?php

namespace Streamstech\Ekpay;

interface Arrayable
{
    public function asArray();
}