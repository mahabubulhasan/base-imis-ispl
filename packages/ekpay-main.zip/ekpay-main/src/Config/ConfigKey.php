<?php

namespace Streamstech\Ekpay\Config;

enum ConfigKey
{
    case MERCHANT_REG_ID;
    case MERCHANT_PAS_KEY;
    case SUCCESS_URL;
    case CANCEL_URL;
    case FAIL_URL;
    case IPN_CHANNEL;
    case IPN_EMAIL;
    case IPN_URI;
    case MAC;
    case SANDBOX_ENABLED;
}