<?php

namespace Streamstech\Ekpay\Config;

use Streamstech\Ekpay\Arrayable;
use Streamstech\Ekpay\Customer;
use Streamstech\Ekpay\Transaction;

class EkpayRequest implements Arrayable
{
    private Customer $customer;
    private Transaction $transaction;
    private Config $config;

    public function __construct(Customer $customer, Transaction $transaction, Config $config)
    {
        $this->customer = $customer;
        $this->transaction = $transaction;
        $this->config = $config;
    }

    public function asArray(): array
    {
        return [
            'mer_info' => $this->config->getMerchantInfo(),
            'req_timestamp' => $this->getTimestamp(),
            'feed_uri' => $this->config->getFeedUri(),
            'cust_info' => $this->customer->asArray(),
            'trns_info' => $this->transaction->asArray(),
            'ipn_info' => $this->config->getIpnInfo(),
            'mac_addr' => $this->config->get(ConfigKey::MAC)
        ];
    }

    private function getTimestamp()
    {
        $date = new \DateTime('now', new \DateTimeZone('Asia/Dhaka'));
        return $date->format('Y-m-d H:i:s') . ' GMT+6';
    }
}