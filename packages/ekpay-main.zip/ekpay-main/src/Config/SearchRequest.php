<?php

namespace Streamstech\Ekpay\Config;

use Streamstech\Ekpay\Arrayable;
use Streamstech\Ekpay\Customer;
use Streamstech\Ekpay\Transaction;

class SearchRequest implements Arrayable
{
    private string $transaction_id;
    private string $date;
    private Config $config;

    /**
     * @param string $transaction_id
     * @param string $date, example: 2026-07-22
     * @param Config $config
     * @example
     * ```
     * new SearchRequest('TRX123456', '2026-07-22', $config);
     * ```
     */
    public function __construct(string $transaction_id, string $date, Config $config)
    {
        $this->transaction_id = $transaction_id;
        $this->date = $date;
        $this->config = $config;
    }

    public function asArray(): array
    {
        return [
            'username' => $this->config->get(ConfigKey::MERCHANT_REG_ID),
            'trnx_id' => $this->transaction_id,
            'trans_date' => $this->date,
        ];
    }
}