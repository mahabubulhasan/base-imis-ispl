<?php

namespace Streamstech\Ekpay\Config;

class Config
{
    private array $configs = [];

    public function set(ConfigKey $key, string $value): static
    {
        $this->configs[$key->name] = $value;
        return $this;
    }

    public function getMerchantInfo(): array
    {
        return [
            'mer_reg_id' => $this->get(ConfigKey::MERCHANT_REG_ID),
            'mer_pas_key' => $this->get(ConfigKey::MERCHANT_PAS_KEY)
        ];
    }

    public function get(ConfigKey $key, mixed $default = '')
    {
        return $this->configs[$key->name] ?? $default;
    }

    public function getFeedUri(): array
    {
        return [
            's_uri' => $this->get(ConfigKey::SUCCESS_URL),
            'f_uri' => $this->get(ConfigKey::FAIL_URL),
            'c_uri' => $this->get(ConfigKey::CANCEL_URL)
        ];
    }

    public function getIpnInfo(): array
    {
        return [
            'ipn_channel' => $this->get(ConfigKey::IPN_CHANNEL),
            'ipn_email' => $this->get(ConfigKey::IPN_EMAIL),
            'ipn_uri' => $this->get(ConfigKey::IPN_URI)
        ];
    }

    public function getEkpayTokenUrl(): string
    {
        if ($this->get(ConfigKey::SANDBOX_ENABLED, true)) {
            return 'https://sandbox.ekpay.gov.bd/ekpaypg/v1/merchant-api';
        } else {
            return 'https://pg.ekpay.gov.bd/ekpaypg/v1/merchant-api';
        }
    }

    public function getEkpayRedirectUrl(): string
    {
        if ($this->get(ConfigKey::SANDBOX_ENABLED, true)) {
            return 'https://sandbox.ekpay.gov.bd/ekpaypg/v1';
        } else {
            return 'https://pg.ekpay.gov.bd/ekpaypg/v1';
        }
    }

    public function getEkpaySearchTransactionUrl(): string
    {
        if ($this->get(ConfigKey::SANDBOX_ENABLED, true)) {
            return 'https://sandbox.ekpay.gov.bd/ekpaypg/v1/search-transaction';
        } else {
            return 'https://pg.ekpay.gov.bd/ekpaypg/v1/search-transaction';
        }
    }
}